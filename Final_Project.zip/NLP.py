__author__ = "Suhas Jagadish"

import csv
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score
from sklearn import svm
from sklearn.naive_bayes import BernoulliNB

# with open('yelp_academic_dataset_review.csv','r') as file:
#    reader = csv.reader(file,delimiter = ',')
#    for i in range(2):
#        print(reader.next())

def evaluate_model(target_true,target_predicted):
    print(classification_report(target_true,target_predicted))
    print("The accuracy score is {:.2%}".format(accuracy_score(target_true,target_predicted)))
    print("")

with open('review_extract_NLP_actual1.csv') as csv_file:
    reader = csv.reader(csv_file, delimiter=",", quotechar='"')
    data = []
    target = []
    for row in reader:
        if row[0] and row[1]:
            data.append(row[0])
            target.append(row[1])

X_train, X_test, y_train, y_test = train_test_split(data, target, test_size=0.25, random_state=0)

# Bag of words representation
count_vectorizer = CountVectorizer(analyzer='word', stop_words='english')
data1 = count_vectorizer.fit_transform(X_train)

# bigram vectorizer
bigram_vectorizer = CountVectorizer(analyzer='word', ngram_range=(1, 2), stop_words='english')
data_bigram = bigram_vectorizer.fit_transform(X_train)

# trigram vectorizer
trigram_vectorizer = CountVectorizer(analyzer='word', ngram_range=(1, 3), stop_words='english')
data_trigram = trigram_vectorizer.fit_transform(X_train)


# BOW tf-idf
tfidf_transformer = TfidfTransformer()
data_final = tfidf_transformer.fit_transform(data1)

# bigram tf-idf
tfidf_transformer_bi = TfidfTransformer()
data_final_bigram = tfidf_transformer_bi.fit_transform(data_bigram)

# trigram tf-idf
tfidf_transformer_tri = TfidfTransformer()
data_final_trigram = tfidf_transformer_tri.fit_transform(data_trigram)

# BOW and tf-idf for test data
data2 = count_vectorizer.transform(X_test)
data_testing = tfidf_transformer.transform(data2)

# bigram for test data
data2_bigram = bigram_vectorizer.transform(X_test)
data_testing_bigram = tfidf_transformer_bi.transform(data2_bigram)

# trigram for test data
data2_trigram = trigram_vectorizer.transform(X_test)
data_testing_trigram = tfidf_transformer_tri.transform(data2_trigram)

# knn with BOW
print("KNN with Bag of words model")
print("---------------------------")
neigh = KNeighborsClassifier(n_neighbors=4)
neigh.fit(data_final, y_train)
predicted = neigh.predict(data_testing)
evaluate_model(y_test,predicted)

# knn with bigram
print("KNN with bigram model")
print("---------------------------")
neigh = KNeighborsClassifier(n_neighbors=4)
neigh.fit(data_final_bigram, y_train)
predicted_bi = neigh.predict(data_testing_bigram)
evaluate_model(y_test,predicted_bi)

# knn with trigram
print("KNN with trigram model")
print("---------------------------")
neigh = KNeighborsClassifier(n_neighbors=4)
neigh.fit(data_final_trigram, y_train)
predicted_tri = neigh.predict(data_testing_trigram)
evaluate_model(y_test,predicted_tri)


# svm with BOW
print("SVM with Bag of Words model")
print("---------------------------")
clf = svm.LinearSVC()
clf.fit(data_final, y_train)
predicted1 = clf.predict(data_testing)
evaluate_model(y_test,predicted1)

# svm with bigram
print("SVM with bigram model")
print("---------------------------")
clf = svm.LinearSVC()
clf.fit(data_final_bigram, y_train)
predicted1_bi = clf.predict(data_testing_bigram)
evaluate_model(y_test,predicted1_bi)

# svm with trigram
print("SVM with trigram model")
print("---------------------------")
clf = svm.LinearSVC()
clf.fit(data_final_trigram, y_train)
predicted1_tri = clf.predict(data_testing_trigram)
evaluate_model(y_test,predicted1_tri)

# NB with BOW
print("NB with Bag of Words model")
print("---------------------------")
gnb = BernoulliNB()
gnb.fit(data_final, y_train)
predicted2 = gnb.predict(data_testing)
evaluate_model(y_test,predicted2)

# NB with bigram
print("NB with bigram model")
print("---------------------------")
gnb = BernoulliNB()
gnb.fit(data_final_bigram, y_train)
predicted2_bi = gnb.predict(data_testing_bigram)
evaluate_model(y_test,predicted2_bi)

# NB with trigram
print("NB with trigram model")
print("---------------------------")
gnb = BernoulliNB()
gnb.fit(data_final_trigram, y_train)
predicted2_tri = gnb.predict(data_testing_trigram)
evaluate_model(y_test,predicted2_tri)