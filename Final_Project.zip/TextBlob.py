__author__ = "Suhas Jagadish"

from textblob import TextBlob
from textblob.classifiers import NaiveBayesClassifier
from textblob.sentiments import NaiveBayesAnalyzer
from textblob.sentiments import PatternAnalyzer
import csv
import sys
reload(sys)
sys.setdefaultencoding("utf-8")

TP=0
FP=0
TN=0
FN=0
prec=0
rec=0
f1=0
acc=0
with open('review_extract_NLP_actual1.csv') as csv_file:
    reader = csv.reader(csv_file, delimiter=",", quotechar='"')
    for row in reader:
        if row[0] and row[1]:
            blob = TextBlob(row[0])
            if row[1] == "good":
                if blob.sentiment.polarity > 0:
                    TP=TP+1
                elif blob.sentiment.polarity < 0:
                    FN=FN+1
                else:
                    pass
            elif row[1] == "bad":
                if blob.sentiment.polarity < 0:
                    TN=TN+1
                elif blob.sentiment.polarity > 0:
                    FP=FP+1
                else:
                    pass
            else:
                pass
            '''
            if blob.sentiment.polarity > 0:
                if row[1] == "good":
                    TP = TP+1
                else:
                    FP = FP+1
            elif blob.sentiment.polarity < 0:
                if row[1] == "bad":
                    TP = TP+1
                else:
                    FP = FP+1
            else:
                pass
            #data.append(row[0])
            #target.append(row[1])
            '''
print TP
print FP
print TN
print FN
#acc = float(TP)/(TP+FP)*100
prec = TP/float(TP+FP)
rec = TP/float(TP+FN)
f1 = 2*((prec*rec)/(prec+rec))
acc = ((TP+TN)/float(TP+TN+FP+FN))*100

print "Precision: " + str(prec)
print "Recall: " + str(rec)
print "F1-score: " + str(f1)
print "Accuracy: " + str(acc)