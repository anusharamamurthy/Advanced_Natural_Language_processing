# import pandas as pd
# #from nltk.corpus import stopwords
# import string
#
# #stop = stopwords.words('english')
#
# df = pd.read_csv('yelp_dataset.csv',encoding='utf8')
# # df['text'] = df['text'].apply(lambda x: [item for item in x if item not in stop])
#
#
# Remove punctuation, digits and stop words.


def sanitize_content(content):
    content = content.lower()
    punct_dict = {}
    digit_dict = {}
    for punct in string.punctuation:
        punct_dict[punct] = None
    for digit in string.digits:
        digit_dict[digit] = None

    content = content.replace('\n',' ')
    content = content.replace('\r','')

    translation_table = str.maketrans(punct_dict) # ' '*len(string.punctuation)
    content = content.translate(translation_table)
    translation_table = str.maketrans(digit_dict) # , ' ' * len(string.digits)
    content = content.translate(translation_table)
    #sanitized_content = [word for word in content.split() if word not in stopWords and len(word) > 2]
    return content
#
# def remove_punctuation(s):
#     sanitized_words = sanitize_content(s)
#     return sanitized_words#''.join(sanitized_words)
#
# df['text'] = df['text'].apply(remove_punctuation)
#
# df_good = df['text'].ix[df['stars']=='good']
# df_bad = df['text'].ix[df['stars']=='bad']
#
# df_bad.to_csv("bad_reviews.txt",index=False)
# df_good.to_csv("good_reviews.txt",index=False)

import string
import csv

filename = 'yelp_dataset.csv'
good_sentences = []
bad_sentences = []
with open(filename,'r') as file:
    for row in csv.reader(file,skipinitialspace = True):
        if row[1] == 'neutral':
            continue
        sanitized_words = sanitize_content(row[0])
        if row[1] == 'good':
            good_sentences.append(sanitized_words)
        else:
            bad_sentences.append(sanitized_words)

good_file = open('good_reviews.txt','w',encoding='utf-8')

good_sentences.pop(0)
bad_sentences.pop(0)

for sentence in good_sentences:
    good_file.write(sentence)
    good_file.write('\n')

bad_file = open('bad_reviews.txt','w',encoding='utf-8')

for sentence in bad_sentences:
    bad_file.write(sentence)
    bad_file.write('\n')

good_file.close()
bad_file.close()

