# Idea from: https://github.com/linanqiu/word2vec-sentiments

# gensim modules
from gensim import utils
from gensim.models.doc2vec import LabeledSentence
from gensim.models import Doc2Vec
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

# numpy
import numpy

# shuffle
from random import shuffle

# logging
import logging
import os.path
import sys
import pickle

program = os.path.basename(sys.argv[0])
logger = logging.getLogger(program)
logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s')
logging.root.setLevel(level=logging.INFO)
logger.info("running %s" % ' '.join(sys.argv))


class LabeledLineSentence(object):

    def __init__(self, sources):
        self.sources = sources

        flipped = {}

        # make sure that keys are unique
        for key, value in sources.items():
            if value not in flipped:
                flipped[value] = [key]
            else:
                raise Exception('Non-unique prefix encountered')

    def __iter__(self):
        for source, prefix in self.sources.items():
            with utils.smart_open(source) as fin:
                for item_no, line in enumerate(fin):
                    yield LabeledSentence(utils.to_unicode(line).split(), [prefix + '_%s' % item_no])

    def to_array(self):
        self.sentences = []
        for source, prefix in self.sources.items():
            with utils.smart_open(source) as fin:
                for item_no, line in enumerate(fin):
                    self.sentences.append(LabeledSentence(
                        utils.to_unicode(line).split(), [prefix + '_%s' % item_no]))
        return self.sentences

    def sentences_perm(self):
        shuffle(self.sentences)
        return self.sentences


sources = {'bad_reviews_test.txt':'TEST_NEG', 'good_reviews_test.txt':'TEST_POS', 'bad_reviews.txt':'TRAIN_NEG', 'good_reviews.txt':'TRAIN_POS'}


sentences = LabeledLineSentence(sources)

model = Doc2Vec(min_count=1, window=10, size=100, sample=1e-4, negative=5, workers=7)

model.build_vocab(sentences.to_array())

for epoch in range(20):
    logger.info('Epoch %d' % epoch)
    model.train(sentences.sentences_perm())

model.save('./model.d2v')


model = Doc2Vec.load('./model.d2v')

logging.info('Sentiment')
train_arrays = numpy.zeros((6203, 100))
train_labels = numpy.zeros(6203)

for i in range(5151):
    prefix_train_pos = 'TRAIN_POS_' + str(i)
    #prefix_train_neg = 'TRAIN_NEG_' + str(i)
    train_arrays[i] = model.docvecs[prefix_train_pos]
    #train_arrays[12500 + i] = model.docvecs[prefix_train_neg]
    train_labels[i] = 1
    #train_labels[12500 + i] = 0

for i in range(5151,6203):
    prefix_train_neg = 'TRAIN_NEG_' + str(i-5151)
    train_arrays[i] = model.docvecs[prefix_train_neg]
    train_labels[i] = 0

print (train_labels)

test_arrays = numpy.zeros((2270, 100))
test_labels = numpy.zeros(2270)

for i in range(1029):
    prefix_test_pos = 'TEST_POS_' + str(i)
    #prefix_test_neg = 'TEST_NEG_' + str(i)
    test_arrays[i] = model.docvecs[prefix_test_pos]
    #test_arrays[12500 + i] = model.docvecs[prefix_test_neg]
    test_labels[i] = 1
    #test_labels[12500 + i] = 0

for i in range(1029,2270):
    prefix_test_neg = 'TEST_NEG_' + str(i-1029)
    test_arrays[i] = model.docvecs[prefix_test_neg]
    test_labels[i] = 0


logging.info('Fitting')
classifier = LogisticRegression()
classifier.fit(train_arrays, train_labels)

LogisticRegression(C=1.0, class_weight=None, dual=False, fit_intercept=True,
          intercept_scaling=1, penalty='l2', random_state=None, tol=0.0001)

pred = classifier.predict(test_arrays)

print (classifier.score(test_arrays, test_labels))

print(classification_report(test_labels,pred))

