from senti_classifier import senti_classifier as sc
import csv
import pickle
import sys
import os
reload(sys)
sys.setdefaultencoding('utf-8')

confusionMatrix = {'good':[0,0], 'bad':[0,0]}
indexDict = {'good': 0,'bad': 1}


def calculateScore(review):
	sentences = [review[0].strip()]
	pos_score, neg_score = sc.polarity_scores(sentences)
	reviewRating = 'good' if pos_score >= neg_score else 'bad'
	confusionMatrix[review[1]][indexDict[reviewRating]] += 1


def readFile(fileName):
	fileContents = []
	with open(fileName, 'rb') as f:
		reader = csv.reader(f, dialect='excel', delimiter=',')
		for row in reader:
			if row[1] != 'neutral':
				fileContents.append(row)
	f.close()
	return fileContents[1:len(fileContents)]

if __name__ == '__main__':
	content = readFile('review_extract_NLP.csv')
	for eachReview in content:
		calculateScore(eachReview)
	with open('confusionMatrix', 'wb') as file:
		pickle.dump(confusionMatrix, file)
	file.close()
